﻿namespace Multiple_Implement
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}