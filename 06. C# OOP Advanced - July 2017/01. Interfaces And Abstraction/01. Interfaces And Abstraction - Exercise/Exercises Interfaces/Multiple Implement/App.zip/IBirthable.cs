﻿namespace Multiple_Implement
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}