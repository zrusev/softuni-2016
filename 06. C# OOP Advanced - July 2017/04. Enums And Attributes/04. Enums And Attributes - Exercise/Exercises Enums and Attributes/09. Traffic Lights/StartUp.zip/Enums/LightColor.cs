﻿namespace _09.Traffic_Lights.Enums
{
    public enum LightColor
    {
        Red,
        Green,
        Yellow
    }
}